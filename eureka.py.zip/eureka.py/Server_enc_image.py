# -*- coding: utf-8 -*-

from CHAM_generalization import *
import socket
import os
import base64  # Base64 인코딩을 위한 모듈


mk_low = [0x0100, 0x0302, 0x0504, 0x0706, 0x0908, 0x0b0a, 0x0d0c, 0x0f0e]
mk_medium = [0x03020100, 0x07060504, 0x0b0a0908, 0x0f0e0d0c]
mk_high = [0x03020100, 0x07060504, 0x0b0a0908, 0x0f0e0d0c, 0xf3f2f1f0, 0xf7f6f5f4, 0xfbfaf9f8, 0xfffefdfc]

# Create a socket object (소켓 생성)
s = socket.socket()
host = "127.0.0.1"
port = 5580

s.bind((host, port))
s.listen(1)
print("Server is listening for incoming connections")

cs, addr = s.accept()
print(f"Connection from: {addr}")

# 보안 레벨 수신
security_level = cs.recv(2500).decode()
print(f"Received security level: {security_level}")

# 보안 레벨에 따른 처리
if security_level == 'low':
    k = 128
    w = 16
    r = 88
    mk = mk_low

elif security_level == 'medium':
    k = 128
    w = 32
    r = 112
    mk = mk_medium

elif security_level == 'high':
    k = 256
    w = 32
    r = 120
    mk = mk_high

else:
    print(f"Error: Unknown security level {security_level}")
    cs.close()
    exit()  # 보안 레벨이 유효하지 않으면 서버를 종료합니다.

# 보안 레벨에 따른 라운드 키 생성
rk = CHAM_key_schedule(mk, k, w)

# 보안 레벨에 따른 라운드 키 생성
rk = CHAM_key_schedule(mk, k, w)

while True:
    # receive data from client
    recv_data = cs.recv(25000)
    print(f"Received data: {recv_data}")

    recv_data_ints = bytes_to_int(recv_data)

    print(f"Encryped data: {recv_data_ints}")

    # 복호화 수행 (암호문 복호화)
    decrypted_data_ints = CHAM_CTR_Encryption(recv_data_ints, rk, len(recv_data_ints), k, w, r)
    print(f"Origin data: {decrypted_data_ints}")

    # 복호화된 정수 리스트를 바이트로 변환
    decrypted_bytes = int_to_bytes(decrypted_data_ints)

    # 바이너리 파일로 저장
    with open("decrypted_penguin.png", "wb") as f:
        f.write(decrypted_bytes)
    print("Decrypted image saved as decrypted_penguin.png")

    # #바이트를 문자열로
    # recv_message_bytes = decrypted_bytes.decode('utf-8')
    
    # print(f"Decrypted message: {recv_message_bytes}")

    break

cs.close()