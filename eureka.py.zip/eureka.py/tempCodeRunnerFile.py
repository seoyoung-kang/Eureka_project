ata_ints = CHAM_CTR_Encryption(recv_data_ints,rk,len(recv_data_ints), k, w, r)
    #print(f"Origi